<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Tileset" tilewidth="16" tileheight="16" tilecount="10" columns="10">
 <image source="Tileset.png" width="160" height="16"/>
</tileset>
