export { default } from "./NavTabs";
